package com.example.AppGestionBank.exceptions;

public class MontantNotSufficientException extends RuntimeException {
    public MontantNotSufficientException(String message) {
        super(message);
    }
}
