package com.example.AppGestionBank.exceptions;

public class CompteSuspendedException extends Exception {
    public CompteSuspendedException(String message) {
        super(message);
    }
}
