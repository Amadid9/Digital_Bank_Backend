package com.example.AppGestionBank.dto;

import com.example.AppGestionBank.entities.enums.TypeOp;
import lombok.Data;

@Data
public class CompteResponse {

    //private Long id;
    private String id;
    private String type;
    private double solde;
    private String statut;
    private String devise;
    private Long clientId;
}