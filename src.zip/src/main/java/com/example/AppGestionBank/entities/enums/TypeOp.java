package com.example.AppGestionBank.entities.enums;

public enum TypeOp {
    CREDIT, DEBIT
}
