package com.example.AppGestionBank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppGestionBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
